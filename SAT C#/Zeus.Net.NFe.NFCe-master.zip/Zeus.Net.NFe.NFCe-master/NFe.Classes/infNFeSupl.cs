﻿namespace NFe.Classes
{
    public class infNFeSupl
    {
        /// <summary>
        /// ZX02 - Texto com o QR-Code impresso no DANFE NFC-e
        /// </summary>
        public string qrCode { get; set; }
    }
}