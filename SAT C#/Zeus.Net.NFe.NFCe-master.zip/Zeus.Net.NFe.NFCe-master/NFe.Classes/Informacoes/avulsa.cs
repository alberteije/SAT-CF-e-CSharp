﻿/********************************************************************************/
/* Projeto: Biblioteca ZeusNFe                                                  */
/* Biblioteca C# para emissão de Nota Fiscal Eletrônica - NFe e Nota Fiscal de  */
/* Consumidor Eletrônica - NFC-e (http://www.nfe.fazenda.gov.br)                */
/*                                                                              */
/* Direitos Autorais Reservados (c) 2014 Adenilton Batista da Silva             */
/*                                       Zeusdev Tecnologia LTDA ME             */
/*                                                                              */
/*  Você pode obter a última versão desse arquivo no GitHub                     */
/* localizado em https://github.com/adeniltonbs/Zeus.Net.NFe.NFCe               */
/*                                                                              */
/*                                                                              */
/*  Esta biblioteca é software livre; você pode redistribuí-la e/ou modificá-la */
/* sob os termos da Licença Pública Geral Menor do GNU conforme publicada pela  */
/* Free Software Foundation; tanto a versão 2.1 da Licença, ou (a seu critério) */
/* qualquer versão posterior.                                                   */
/*                                                                              */
/*  Esta biblioteca é distribuída na expectativa de que seja útil, porém, SEM   */
/* NENHUMA GARANTIA; nem mesmo a garantia implícita de COMERCIABILIDADE OU      */
/* ADEQUAÇÃO A UMA FINALIDADE ESPECÍFICA. Consulte a Licença Pública Geral Menor*/
/* do GNU para mais detalhes. (Arquivo LICENÇA.TXT ou LICENSE.TXT)              */
/*                                                                              */
/*  Você deve ter recebido uma cópia da Licença Pública Geral Menor do GNU junto*/
/* com esta biblioteca; se não, escreva para a Free Software Foundation, Inc.,  */
/* no endereço 59 Temple Street, Suite 330, Boston, MA 02111-1307 USA.          */
/* Você também pode obter uma copia da licença em:                              */
/* http://www.opensource.org/licenses/lgpl-license.php                          */
/*                                                                              */
/* Zeusdev Tecnologia LTDA ME - adenilton@zeusautomacao.com.br                  */
/* http://www.zeusautomacao.com.br/                                             */
/* Rua Comendador Francisco josé da Cunha, 111 - Itabaiana - SE - 49500-000     */
/********************************************************************************/
namespace NFe.Classes.Informacoes
{
    public class avulsa
    {
        private decimal _vDar;

        /// <summary>
        ///     D02 - CNPJ do órgão emitente
        /// </summary>
        public string CNPJ { get; set; }

        /// <summary>
        ///     D03 - Órgão emitente
        /// </summary>
        public string xOrgao { get; set; }

        /// <summary>
        ///     D04 - Matrícula do agente do Fisco
        /// </summary>
        public string matr { get; set; }

        /// <summary>
        ///     D05 - Nome do agente do Fisco
        /// </summary>
        public string xAgente { get; set; }

        /// <summary>
        ///     D06 - Telefone
        /// </summary>
        public string fone { get; set; }

        /// <summary>
        ///     D07 - Sigla da UF
        /// </summary>
        public string UF { get; set; }

        /// <summary>
        ///     D08 - Número do Documento de Arrecadação de Receita
        /// </summary>
        public string nDAR { get; set; }

        /// <summary>
        ///     D09 - Data de emissão do Documento de Arrecadação
        /// </summary>
        public string dEmi { get; set; }

        /// <summary>
        ///     D10 - Valor Total constante no Documento de arrecadação de Receita
        /// </summary>
        public decimal vDAR
        {
            get { return _vDar; }
            set { _vDar = Valor.Arredondar(value, 2); }
        }

        /// <summary>
        ///     D11 - Repartição Fiscal emitente
        /// </summary>
        public string repEmi { get; set; }

        /// <summary>
        ///     D12 - Data de pagamento do Documento de Arrecadação
        /// </summary>
        public string dPag { get; set; }
    }
}